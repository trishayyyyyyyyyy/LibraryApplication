﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_69757
{
     class AudioBooks: Books
    {
        private string _narrator;
        private string _duration;

        public AudioBooks(string title, string aurthur, string category, string narrator, string duration) :
         base(title, aurthur, category, "Audiobooks")
        {
            _narrator = narrator;
            _duration = duration;
        }
        public string Narrator
        {
            get { return _narrator; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    _narrator = value.Trim();
                }
                else
                {
                    throw new Exception(" The narrator cannot be empty.");
                }
            }
        }
        public string Duration
        {
            get { return _duration; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    _duration = value.Trim();
                }
                else
                {
                    throw new Exception(" The narrator cannot be empty.");
                }
            }
        }



    }
}
