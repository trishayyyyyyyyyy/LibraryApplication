﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_69757
{
     class Books
    {
        private string _title;
        private string _aurthur;
        private string _category;
        private string _type;

        public Books(string title, string aurthur, string category, string type)
        {
            Title = title;
            Aurthur = aurthur;
            Category = category;
            _type = type;
        }

        public string Type
        {
            get { return _type; }
        }


        public string Title
        {
            get { return _title; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    _title = value.Trim();
                }
                else
                {
                    throw new Exception(" The title name cannot be empty.");
                }
            }
        }

        public string Aurthur
        {
            get { return _aurthur; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim())))
                {
                    _aurthur = value;
                }
                else
                {
                   
                    throw new Exception("the aurthur cannot be empty");
                }

            }
        }

        public string Category
        {
            get { return _category; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim())))
                {
                    _category = value;
                }
                else
                {
                    
                    throw new Exception("the category cannot be empty");
                }

            }
        }
    }
   

    

}
