﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_69757
{
     class E_books : Books
    {
        private string _format;
        private string _fileSize;

        public E_books(string title, string aurthur, string category, string format, string fileSize) :
           base(title, aurthur, category, "E_books")
        {
            _format = format;
            _fileSize = fileSize;
        }
        public string Format
        {
            get { return _format; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    _format = value.Trim();
                }
                else
                {
                    throw new Exception(" The Format cannot be empty.");
                }
            }
        }
        public string FileSize
        {
            get { return _fileSize; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    Format = value.Trim();
                }
                else
                {
                    throw new Exception(" The fileSize cannot be empty.");
                }
            }
        }
    }
}
