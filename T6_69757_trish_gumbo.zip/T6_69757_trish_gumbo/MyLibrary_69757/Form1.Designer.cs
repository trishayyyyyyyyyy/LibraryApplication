﻿namespace MyLibrary_69757
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.paperbox = new System.Windows.Forms.GroupBox();
            this.egroupbox = new System.Windows.Forms.GroupBox();
            this.audiogroupbox = new System.Windows.Forms.GroupBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.bttnpaper = new System.Windows.Forms.Button();
            this.bttnEbook = new System.Windows.Forms.Button();
            this.bttnAudio = new System.Windows.Forms.Button();
            this.paperbox.SuspendLayout();
            this.egroupbox.SuspendLayout();
            this.audiogroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(129, 71);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 22);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(442, 71);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 22);
            this.textBox2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 76);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Title:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(355, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 16);
            this.label2.TabIndex = 3;
            this.label2.Text = "Category:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 144);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(51, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Aurthur:";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(129, 144);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 22);
            this.textBox3.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(355, 150);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 16);
            this.label4.TabIndex = 6;
            this.label4.Text = "Type:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "E_books",
            "AudioBooks",
            "Paperbooks"});
            this.comboBox1.Location = new System.Drawing.Point(442, 150);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 7;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // paperbox
            // 
            this.paperbox.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.paperbox.Controls.Add(this.bttnpaper);
            this.paperbox.Controls.Add(this.label6);
            this.paperbox.Controls.Add(this.label5);
            this.paperbox.Controls.Add(this.textBox7);
            this.paperbox.Controls.Add(this.textBox4);
            this.paperbox.Enabled = false;
            this.paperbox.Location = new System.Drawing.Point(12, 231);
            this.paperbox.Name = "paperbox";
            this.paperbox.Size = new System.Drawing.Size(412, 173);
            this.paperbox.TabIndex = 8;
            this.paperbox.TabStop = false;
            this.paperbox.Text = "PaperBook";
            this.paperbox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // egroupbox
            // 
            this.egroupbox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.egroupbox.Controls.Add(this.bttnEbook);
            this.egroupbox.Controls.Add(this.label8);
            this.egroupbox.Controls.Add(this.label7);
            this.egroupbox.Controls.Add(this.textBox8);
            this.egroupbox.Controls.Add(this.textBox5);
            this.egroupbox.Enabled = false;
            this.egroupbox.Location = new System.Drawing.Point(430, 231);
            this.egroupbox.Name = "egroupbox";
            this.egroupbox.Size = new System.Drawing.Size(373, 173);
            this.egroupbox.TabIndex = 9;
            this.egroupbox.TabStop = false;
            this.egroupbox.Text = "E-Book";
            // 
            // audiogroupbox
            // 
            this.audiogroupbox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.audiogroupbox.Controls.Add(this.bttnAudio);
            this.audiogroupbox.Controls.Add(this.label9);
            this.audiogroupbox.Controls.Add(this.label10);
            this.audiogroupbox.Controls.Add(this.textBox9);
            this.audiogroupbox.Controls.Add(this.textBox6);
            this.audiogroupbox.Enabled = false;
            this.audiogroupbox.Location = new System.Drawing.Point(820, 231);
            this.audiogroupbox.Name = "audiogroupbox";
            this.audiogroupbox.Size = new System.Drawing.Size(340, 173);
            this.audiogroupbox.TabIndex = 10;
            this.audiogroupbox.TabStop = false;
            this.audiogroupbox.Text = "AudioBook";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(136, 51);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 22);
            this.textBox4.TabIndex = 11;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(147, 51);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 22);
            this.textBox5.TabIndex = 12;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(117, 54);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 22);
            this.textBox6.TabIndex = 12;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(136, 111);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 22);
            this.textBox7.TabIndex = 12;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(147, 114);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 22);
            this.textBox8.TabIndex = 13;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(117, 105);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(100, 22);
            this.textBox9.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(21, 51);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 16);
            this.label5.TabIndex = 11;
            this.label5.Text = "ISBN";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(21, 117);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 16);
            this.label6.TabIndex = 13;
            this.label6.Text = "Pages";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(52, 54);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 14;
            this.label7.Text = "Format";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(52, 111);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 16);
            this.label8.TabIndex = 15;
            this.label8.Text = "File Size";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 57);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 16);
            this.label9.TabIndex = 16;
            this.label9.Text = "Narrator";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(28, 111);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(57, 16);
            this.label10.TabIndex = 17;
            this.label10.Text = "Duration";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 446);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(1150, 69);
            this.button1.TabIndex = 11;
            this.button1.Text = "BACK TO MENU";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // bttnpaper
            // 
            this.bttnpaper.Location = new System.Drawing.Point(278, 67);
            this.bttnpaper.Name = "bttnpaper";
            this.bttnpaper.Size = new System.Drawing.Size(97, 47);
            this.bttnpaper.TabIndex = 12;
            this.bttnpaper.Text = "Add";
            this.bttnpaper.UseVisualStyleBackColor = true;
            this.bttnpaper.Click += new System.EventHandler(this.bttnpaper_Click);
            // 
            // bttnEbook
            // 
            this.bttnEbook.Location = new System.Drawing.Point(269, 67);
            this.bttnEbook.Name = "bttnEbook";
            this.bttnEbook.Size = new System.Drawing.Size(97, 47);
            this.bttnEbook.TabIndex = 14;
            this.bttnEbook.Text = "Add";
            this.bttnEbook.UseVisualStyleBackColor = true;
            this.bttnEbook.Click += new System.EventHandler(this.bttnEbook_Click);
            // 
            // bttnAudio
            // 
            this.bttnAudio.Location = new System.Drawing.Point(223, 67);
            this.bttnAudio.Name = "bttnAudio";
            this.bttnAudio.Size = new System.Drawing.Size(97, 47);
            this.bttnAudio.TabIndex = 16;
            this.bttnAudio.Text = "Add";
            this.bttnAudio.UseVisualStyleBackColor = true;
            this.bttnAudio.Click += new System.EventHandler(this.bttnAudio_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1188, 571);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.audiogroupbox);
            this.Controls.Add(this.egroupbox);
            this.Controls.Add(this.paperbox);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.paperbox.ResumeLayout(false);
            this.paperbox.PerformLayout();
            this.egroupbox.ResumeLayout(false);
            this.egroupbox.PerformLayout();
            this.audiogroupbox.ResumeLayout(false);
            this.audiogroupbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox paperbox;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.GroupBox egroupbox;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.GroupBox audiogroupbox;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button bttnpaper;
        private System.Windows.Forms.Button bttnEbook;
        private System.Windows.Forms.Button bttnAudio;
    }
}

