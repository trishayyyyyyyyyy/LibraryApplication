﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace MyLibrary_69757
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 0;
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem.ToString() == "Paperbooks")
            {
                //enable the laptop groupBox and disable the otherone
               
                egroupbox.Enabled = false;
                audiogroupbox.Enabled = false;
                paperbox.Enabled = true;
            }
            else if(comboBox1.SelectedItem.ToString()== "E_books")
            {
                paperbox.Enabled = false;
                egroupbox.Enabled = true;
                audiogroupbox.Enabled = false;
            }
            else 
            {
                paperbox.Enabled = false;
                egroupbox.Enabled = false;
                audiogroupbox.Enabled = true;
            }
        }

        private void bttnpaper_Click(object sender, EventArgs e)
        {

            string title = textBox1.Text;
            string aurthur= textBox3.Text;
            string category = textBox2.Text;
            int numOfpages = Convert.ToInt32(textBox7.Text);
            string iSBNnum = textBox4.Text;
            PaperBook myPaperbk = new PaperBook(title, aurthur,category, iSBNnum,numOfpages);
            Library.books.Add(myPaperbk);
            MessageBox.Show("The Paper Book has been added to the database");
            

        }

        private void bttnEbook_Click(object sender, EventArgs e)
        {
            string title = textBox1.Text;
            string aurthur = textBox3.Text;
            string category = textBox2.Text;
            string format = textBox5.Text;
            string fileSize = textBox8.Text;
            E_books myEbk = new E_books(title, aurthur, category, format, fileSize);
            Library.books.Add(myEbk);
            MessageBox.Show("The E-Book has been added to the database");
            

        }

        private void bttnAudio_Click(object sender, EventArgs e)
        {

            string title = textBox1.Text;
            string aurthur = textBox3.Text;
            string category = textBox2.Text;
            string narrator = textBox6.Text;
            string duration = textBox9.Text;
            AudioBooks myAbk = new AudioBooks(title, aurthur, category, narrator, duration);
            Library.books.Add(myAbk);
            MessageBox.Show("The Audio Book has been added to the database");
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            FileStream fs = new FileStream("MyLibrary.txt", FileMode.Append, FileAccess.Write);
            StreamWriter sw = new StreamWriter(fs);

            if (Library.books[0].Type == "Paperbooks")
            {
                PaperBook myPaperbk = (PaperBook)Library.books[0];


                sw.WriteLine(textBox1.Text, textBox2.Text, textBox3.Text,textBox7.Text,textBox4.Text);
                             
            }
            else if (Library.books[0].Type == "E_books")
            {
                E_books myEbk = (E_books)Library.books[0];

                sw.WriteLine(textBox1.Text, textBox2.Text, textBox3.Text, textBox5.Text, textBox8.Text);
               
            }
            else if (Library.books[0].Type == "Audiobooks")
            {
                AudioBooks myAbk = (AudioBooks)Library.books[0];
                sw.WriteLine(textBox1.Text, textBox2.Text, textBox3.Text, textBox6.Text, textBox9.Text);
            }

            sw.Close();
            fs.Close();

            Form f2 = new Form2();
            this.Hide();
            f2.ShowDialog();
            this.Close();
        }
    }
}
