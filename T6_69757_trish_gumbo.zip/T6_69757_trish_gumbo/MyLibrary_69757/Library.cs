﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_69757
{
     class Library
    {
        public static List<Books> books= new List<Books>();
    }
}
