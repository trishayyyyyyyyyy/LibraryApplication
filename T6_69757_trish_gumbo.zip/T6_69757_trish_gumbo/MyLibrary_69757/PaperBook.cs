﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLibrary_69757
{
     class PaperBook : Books
    {
       private  string _iSBNnum;
       private  int _numOfpages;

        public PaperBook( string title, string aurthur, string category,string iSBNum ,int numOfPages):
            base(title , aurthur, category, "Paperbooks")
        {
            _iSBNnum = iSBNum;
            _numOfpages = numOfPages;
        }
        public string ISBNnum
        { get { return _iSBNnum; }
            set
            {
                if ((value.Length > 0) && (!String.IsNullOrEmpty(value.Trim()))) //checking the length of my value if it is not null or empty
                {
                    _iSBNnum = value.Trim();
                }
                else
                {
                    throw new Exception(" The iSBN number  cannot be empty.");
                }
            }
        }
        public int NumOfpages
        {
            get { return _numOfpages; }
            set {
                if (value > 0)
                {
                    _numOfpages = value;
                }
                else
                {
                    //throw an exception
                    throw new Exception("the number of pages cannot be less than 0");
                }
            }
        }
    }
}
